import torch
from torch.nn import Parameter
from torch_geometric.nn import SAGEConv
import torch.nn.functional as F


class GraphSAGE(torch.nn.Module):
    def __init__(self, x, in_channels, hidden_channels, out_channels):
        super().__init__()
        self.node_emb = x
        self.conv1 = SAGEConv(in_channels, hidden_channels)
        self.conv2 = SAGEConv(hidden_channels, out_channels)
        
        
    def encode(self, edge_index):
        x = self.node_emb
        x = self.conv1(x, edge_index).relu()

        return self.conv2(x, edge_index)

    def decode(self, z, edge_label_index):

        return (z[edge_label_index[0]] * z[edge_label_index[1]]).sum(dim=-1)

    def decode_all(self, z):
        prob_adj = z @ z.t()
        return (prob_adj > 0).nonzero(as_tuple=False).t()

    def forward(self, edge_index):

        x = self.node_emb
        embs = []

        x = self.conv1(x, edge_index).relu()
        embs.append(x)  
        x = F.dropout(x, p=0.2, training=self.training)
        x = self.conv2(x, edge_index)
        embs.append(x) 

        embs = torch.stack(embs, dim=1)  
        return x, embs   