

import torch
import random
import numpy as np
import torch.nn.functional as F

from utils.parser import parse_args
from utils.sampler import PuNeg
from utils.sampler import mixgcfrns
from utils.sampler import pooling
from utils.dataloader import create_graph
from PULoss import PULoss

from modules.GCN import GCN
from modules.GraphSAGE import GraphSAGE

from utils.evaluate import test

import torch_geometric.transforms as T


device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

seed = 2022
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
torch.cuda.manual_seed_all(seed)  
np.random.seed(seed)  
random.seed(seed)  
torch.manual_seed(seed)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True
alpha = 0.1

args = parse_args()


transform = T.NormalizeFeatures()
train_data, valid_data, test_data, train_dict = create_graph(args)
train_data, valid_data, test_data = transform(train_data), transform(valid_data), transform(test_data)
train_data, valid_data, test_data = train_data.to(device), valid_data.to(device), test_data.to(device)


if args.gnn == 'GCN':
    model = GCN(train_data.x, 1433, 64, 64).to(device)
elif args.gnn == 'graphsage':
    model = GraphSAGE(train_data.x, 1433, 64, 64).to(device)

optimizer = torch.optim.Adam(params=model.parameters(), lr=0.01)
criterion = torch.nn.BCEWithLogitsLoss()

print(model)
print('sampler:' + args.ns)
print('dataset:' + args.dataset)



def puloss(out, label):
    [out_pos, out_neg, out_target] = out
    [pos_label, neg_label, target_label] = label


    target_loss = criterion(out_target, target_label)

    pos_loss = criterion(out_pos, pos_label)*(alpha/(1-alpha))

    neg_loss = criterion(out_neg, neg_label)*(1/(1-alpha))

    return target_loss + neg_loss + pos_loss



    

def create_bpr_loss(user_gcn_emb, pos_gcn_embs, neg_gcn_embs):

    batch_size = user_gcn_emb.shape[0]

    u_e = pooling(user_gcn_emb)
    pos_e = pooling(pos_gcn_embs)
    neg_e = pooling(neg_gcn_embs.view(-1, neg_gcn_embs.shape[2], neg_gcn_embs.shape[3])).view(batch_size, 1, -1)

    pos_scores = torch.sum(torch.mul(u_e, pos_e), axis=1)
    neg_scores = torch.sum(torch.mul(u_e.unsqueeze(dim=1), neg_e), axis=-1)  

    mf_loss = torch.mean(torch.log(1+torch.exp(neg_scores - pos_scores.unsqueeze(dim=1)).sum(dim=1)))


    regularize = (torch.norm(user_gcn_emb[:, 0, :]) ** 2
                    + torch.norm(pos_gcn_embs[:, 0, :]) ** 2
                    + torch.norm(neg_gcn_embs[:, :, 0, :]) ** 2) / 2  
    emb_loss = 1e-2 * regularize / batch_size

    return mf_loss + emb_loss, mf_loss, emb_loss


def train():
    model.train()
    optimizer.zero_grad()
    z = model.encode(train_data.edge_index) 
    pos_edge_index, neg_edge_index = PuNeg(train_data)
    neg_edge_index = neg_edge_index.to(device)
    
    pos_label = train_data.edge_label.new_ones(pos_edge_index.size(1))
    neg_label = train_data.edge_label.new_zeros(neg_edge_index.size(1))
    target_label = train_data.edge_label

    out_pos = model.decode(z, pos_edge_index).view(-1)
    out_neg = model.decode(z, neg_edge_index).view(-1)
    out_target = model.decode(z, train_data.edge_label_index).view(-1)

    loss = puloss([out_pos, out_neg, out_target],[pos_label,neg_label,target_label])
    
    loss.backward()
    optimizer.step()
    return z, loss


best_val_auc = final_test_auc = final_f1 = 0
epochs = args.epoch

for epoch in range(1, epochs+1):
    z, loss = train()
    valdict = test(model,z, valid_data)
    testdict = test(model,z, test_data)
    val_auc, val_f1 = valdict['auc'], valdict['f1']
    test_auc, test_f1 = testdict['auc'], testdict['f1']
   
    if val_auc > best_val_auc:
        best_val_auc = val_auc
        final_test_auc = test_auc
        final_f1 = test_f1
    print(f'Epoch: {epoch:03d}, Loss: {loss:.4f}, Val: {val_auc:.4f}, '
          f'Test auc: {test_auc:.4f}, f1: {test_f1:.4f}')


print(f'Final Test: {final_test_auc:.4f}, f1: {final_f1:.4f}')


