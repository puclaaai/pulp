from torch_geometric.utils import negative_sampling
import torch
import numpy as np
from tqdm import tqdm
from time import time
import random


@torch.no_grad()
def PuNeg(data):
    neg_index = negative_sampling(
        edge_index=data.edge_index, num_nodes=data.num_nodes,
        num_neg_samples=int(data.edge_label_index.size(1)*1.2), method='sparse')

    list_data_index = [i for i in range(len(data.edge_label_index[0]))]
    
    pos_index = random.sample(list_data_index, int(len(data.edge_label_index[0])/20))
    pos_index_list = torch.cat(
            [data.edge_label_index[0][pos_index].view(1,-1), data.edge_label_index[1][pos_index].view(1,-1)],
            dim=0)
    return pos_index_list, neg_index








