import numpy as np
from scipy import sparse
from numpy import array
from torch_geometric.data import Data
import torch
import torch.nn as nn
from collections import defaultdict
import sys
import os.path as osp
import pickle as pkl
import networkx as nx
import scipy.sparse as sp

def create_graph(args):
    filepath = args.data_path + args.dataset + '/'

    x = np.loadtxt(filepath + 'feature.txt')
    x = torch.tensor(x, dtype=torch.float32)



    train_edge_index, train_edge_label, train_edge_label_index, train_dict = load_train_data(filepath + 'train.txt')
    train_data = Data(x=x, edge_index=train_edge_index, edge_label=train_edge_label, edge_label_index=train_edge_label_index)

    valid_edge_index, valid_edge_label, valid_edge_label_index = load_testOrValid_data(filepath + 'valid.txt')
    valid_data = Data(x=x, edge_index=valid_edge_index, edge_label=valid_edge_label, edge_label_index=valid_edge_label_index)

    test_edge_index, test_edge_label, test_edge_label_index = load_testOrValid_data(filepath + 'test.txt')
    test_data = Data(x=x, edge_index=test_edge_index, edge_label=test_edge_label, edge_label_index=test_edge_label_index)


    return train_data, valid_data, test_data, train_dict

def sie_to_bie(edges):

    edges = np.array(edges)
    edges_ = edges.copy()
    edges_[:, 0], edges_[:, 1] = edges[:, 1], edges[:, 0]
    all_edges = np.concatenate([edges, edges_], axis=0)
    all_edges_index = torch.tensor(np.array(all_edges), dtype=torch.long)

    return all_edges_index
   
def load_train_data(filepathname):
    train_edge_index, train_edge_label_index, train_dict = load_train_edges(filepathname)
    train_edge_label = torch.ones(train_edge_label_index.size()[1])
    return train_edge_index, train_edge_label, train_edge_label_index, train_dict


def load_train_edges(filename):
    print("Loading train data......")
    edges = list()
    with open(filename, 'r') as f:
        for line in f:
            user, item = line.strip().split('\t')
            edges.append((int(user), int(item))) 

    train_dict = defaultdict(list)
    
    for u_id, i_id in edges:
        train_dict[int(u_id)].append(int(i_id))
    
    train_edge_index = sie_to_bie(edges)
    train_edge_index = torch.tensor(np.array(train_edge_index), dtype=torch.long).t().contiguous()

    train_edge_label_index = torch.tensor(np.array(edges), dtype=torch.long).t().contiguous()
    return train_edge_index, train_edge_label_index, train_dict



def load_testOrValid_data(filename):
    print("Loading test/valid data......")
    edges = list()
    labels = list()
    with open(filename, 'r') as f:
        for line in f:
            user, item, label = line.strip().split('\t')
            edges.append((int(user), int(item),))
            labels.append(int(label))
    edge_index = sie_to_bie(edges)    
    edge_index = torch.tensor(np.array(edge_index), dtype=torch.long).t().contiguous()   

    edge_label_index = torch.tensor(np.array(edges), dtype=torch.long).t().contiguous() 
    edge_label = torch.tensor(np.array(labels), dtype=torch.long).t().contiguous() 
    
    return edge_index, edge_label, edge_label_index

def mcns_train_data_list(args):
    filename = args.data_path + args.dataset + '/' + 'train.txt'
    edges = list()
    with open(filename, 'r') as f:
        for line in f:
            user, item = line.strip().split('\t')
            edges.append((int(user), int(item))) 
    return edges