from sklearn.metrics import roc_auc_score
from sklearn.metrics import f1_score
import torch

def get_auc(y, pred):
    return roc_auc_score(y, pred)


def get_f1(y, pred):
    pred = (pred >= 0.5).astype(int)
    return f1_score(y, pred)


@torch.no_grad()
def test(model,z, data):
    result = {'auc': 0., 'f1': 0.}
    out = model.decode(z, data.edge_label_index).view(-1).sigmoid()  

    result['auc'] += get_auc(data.edge_label.cpu().numpy(), out.cpu().numpy())
    result['f1'] += get_f1(data.edge_label.cpu().numpy(), out.cpu().numpy())
    
    return result
